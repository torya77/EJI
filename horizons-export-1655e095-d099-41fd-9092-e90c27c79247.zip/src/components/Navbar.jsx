
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Globe, Menu, X, Map, Languages, Utensils, Calculator, MessageCircle, ShoppingBag, Users } from "lucide-react";
import AlgeriaLogo from "@/components/AlgeriaLogo";

const Navbar = () => {
  const { t, i18n } = useTranslation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
  };

  const menuItems = [
    { path: "/map", icon: Map, label: t('map') },
    { path: "/translator", icon: Languages, label: t('translator') },
    { path: "/restaurants", icon: Utensils, label: t('restaurants') },
    { path: "/exchange", icon: Calculator, label: t('exchange') },
    { path: "/chatbot", icon: MessageCircle, label: t('chatbot') },
    { path: "/marketplace", icon: ShoppingBag, label: t('marketplace') },
    { path: "/community", icon: Users, label: t('community') }
  ];

  return (
    <nav className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <AlgeriaLogo className="h-8 w-8 text-sky-500" />
              <span className="ml-2 text-2xl font-bold text-sky-500">EJI</span>
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            {menuItems.map((item) => (
              <Link key={item.path} to={item.path}>
                <Button variant="ghost" className="flex items-center gap-2">
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Button>
              </Link>
            ))}
            
            <div className="relative">
              <Button
                variant="outline"
                size="icon"
                className="ml-4"
                onClick={() => {
                  const currentLang = i18n.language;
                  const langs = ['fr', 'ar', 'en', 'de'];
                  const nextLang = langs[(langs.indexOf(currentLang) + 1) % langs.length];
                  changeLanguage(nextLang);
                }}
              >
                <Globe className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden"
          >
            <div className="px-2 pt-2 pb-3 space-y-1">
              {menuItems.map((item) => (
                <Link 
                  key={item.path} 
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start gap-2"
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Button>
                </Link>
              ))}
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                onClick={() => {
                  const currentLang = i18n.language;
                  const langs = ['fr', 'ar', 'en', 'de'];
                  const nextLang = langs[(langs.indexOf(currentLang) + 1) % langs.length];
                  changeLanguage(nextLang);
                }}
              >
                <Globe className="h-4 w-4" />
                {t('changeLanguage')}
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
