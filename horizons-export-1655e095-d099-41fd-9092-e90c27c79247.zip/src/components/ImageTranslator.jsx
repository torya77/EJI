
import React from 'react';
import { Button } from '@/components/ui/button';
import { Camera, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { createWorker } from 'tesseract.js';

const ImageTranslator = ({ onTextExtracted, isProcessing, toast }) => {
  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const worker = await createWorker();
      await worker.loadLanguage('ara+fra+eng+deu');
      await worker.initialize('ara+fra+eng+deu');
      const { data: { text } } = await worker.recognize(file);
      await worker.terminate();
      onTextExtracted(text);
      
      toast({
        title: "Texte extrait avec succès",
        description: "Le texte a été extrait de l'image.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible de lire le texte de l'image.",
      });
    }
  };

  return (
    <Button 
      variant="outline" 
      className="w-full relative overflow-hidden"
      disabled={isProcessing}
    >
      {isProcessing ? (
        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
      ) : (
        <Camera className="mr-2" />
      )}
      Scanner un texte
      <input
        type="file"
        accept="image/*"
        capture="environment"
        className="absolute inset-0 opacity-0 cursor-pointer"
        onChange={handleImageUpload}
        disabled={isProcessing}
      />
    </Button>
  );
};

export default ImageTranslator;
