
import React from "react";

const AlgeriaLogo = ({ className }) => {
  return (
    <svg
      className={className}
      width="40"
      height="40"
      viewBox="0 0 100 100"
      fill="#151B54"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M20 20 L80 20 L90 40 L80 80 L20 80 L10 40 Z"
        stroke="#151B54"
        strokeWidth="2"
        fill="#151B54"
      />
      <path
        d="M35 30 L65 30 L70 40 L65 70 L35 70 L30 40 Z"
        stroke="white"
        strokeWidth="1"
        fill="none"
      />
    </svg>
  );
};

export default AlgeriaLogo;
