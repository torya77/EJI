
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Languages, Loader2 } from 'lucide-react';

const TranslationOutput = ({
  text,
  translatedText,
  selectedLanguage,
  setSelectedLanguage,
  languages,
  detectedLanguage,
  isProcessing,
  onTranslate
}) => {
  if (!text) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <select
          value={selectedLanguage}
          onChange={(e) => setSelectedLanguage(e.target.value)}
          className="p-2 border rounded-md focus:ring-2 focus:ring-[#151B54] focus:border-transparent"
        >
          {languages.map((lang) => (
            <option key={lang.code} value={lang.code}>
              {lang.name}
            </option>
          ))}
        </select>

        <Button
          onClick={onTranslate}
          disabled={isProcessing}
          className="bg-[#151B54] hover:bg-[#151B54]/90"
        >
          {isProcessing ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Languages className="mr-2 h-4 w-4" />
          )}
          Traduire
        </Button>
      </div>

      {detectedLanguage && (
        <p className="text-sm text-gray-500">
          Langue détectée : {languages.find(l => l.code === detectedLanguage)?.name || detectedLanguage}
        </p>
      )}

      {translatedText && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-[#151B54]/5 rounded-md"
        >
          <h3 className="font-semibold mb-2 text-[#151B54]">Traduction :</h3>
          <p className="text-gray-700">{translatedText}</p>
        </motion.div>
      )}
    </div>
  );
};

export default TranslationOutput;
