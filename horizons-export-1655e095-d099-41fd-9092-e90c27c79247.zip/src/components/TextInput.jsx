
import React from 'react';
import { Button } from '@/components/ui/button';
import { Type, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const TextInput = ({ text, setText, showTextInput, setShowTextInput, isProcessing }) => {
  return (
    <>
      <Button 
        variant="outline" 
        className="w-full"
        onClick={() => setShowTextInput(true)}
        disabled={isProcessing}
      >
        <Type className="mr-2" />
        Saisir un texte
      </Button>

      <AnimatePresence>
        {showTextInput && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="relative"
          >
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full h-32 p-3 border rounded-md focus:ring-2 focus:ring-[#151B54] focus:border-transparent"
              placeholder="Texte à traduire..."
            />
            <Button
              size="sm"
              variant="ghost"
              className="absolute top-2 right-2"
              onClick={() => setShowTextInput(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default TextInput;
