
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import Navbar from "@/components/Navbar";
import Home from "@/pages/Home";
import Map from "@/pages/Map";
import Translator from "@/pages/Translator";
import Restaurants from "@/pages/Restaurants";
import Exchange from "@/pages/Exchange";
import Chatbot from "@/pages/Chatbot";
import Marketplace from "@/pages/Marketplace";
import Community from "@/pages/Community";
import { I18nextProvider } from "react-i18next";
import i18n from "@/lib/i18n";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/components/ui/use-toast";

function App() {
  const { toast } = useToast();

  React.useEffect(() => {
    // Écouter les changements d'authentification
    const { data: authListener } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN') {
        toast({
          title: "Connexion réussie",
          description: "Bienvenue sur EJI !",
        });
      } else if (event === 'SIGNED_OUT') {
        toast({
          title: "Déconnexion",
          description: "À bientôt !",
        });
      }
    });

    // Vérifier la session actuelle
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        toast({
          title: "Session active",
          description: "Bienvenue sur EJI !",
        });
      }
    };

    checkSession();

    return () => {
      if (authListener) authListener.subscription.unsubscribe();
    };
  }, [toast]);

  return (
    <I18nextProvider i18n={i18n}>
      <Router>
        <div className="min-h-screen bg-gradient-to-b from-blue-900/5 to-orange-50">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/map" element={<Map />} />
            <Route path="/translator" element={<Translator />} />
            <Route path="/restaurants" element={<Restaurants />} />
            <Route path="/exchange" element={<Exchange />} />
            <Route path="/chatbot" element={<Chatbot />} />
            <Route path="/marketplace" element={<Marketplace />} />
            <Route path="/community" element={<Community />} />
          </Routes>
          <Toaster />
        </div>
      </Router>
    </I18nextProvider>
  );
}

export default App;
