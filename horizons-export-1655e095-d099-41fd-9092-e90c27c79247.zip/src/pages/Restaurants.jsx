
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Star, Coffee, Utensils } from 'lucide-react';

const Restaurants = () => {
  const [preferences, setPreferences] = useState({
    cuisine: [],
    priceRange: '',
    dietary: []
  });

  const [recommendations, setRecommendations] = useState([]);

  return (
    <div className="container mx-auto p-6">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-lg p-6"
        >
          <h2 className="text-2xl font-bold mb-6">Trouvez votre restaurant idéal</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold mb-3">Type de cuisine</h3>
              {/* Cuisine preferences */}
            </div>

            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold mb-3">Budget</h3>
              {/* Price range selection */}
            </div>

            <div className="p-4 border rounded-lg">
              <h3 className="font-semibold mb-3">Régime alimentaire</h3>
              {/* Dietary preferences */}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {recommendations.map((restaurant, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-lg shadow p-4"
              >
                <img  alt="Restaurant ambiance" className="w-full h-48 object-cover rounded-lg mb-4" src="https://images.unsplash.com/photo-1701374489848-48d3bfbe2664" />
                <h3 className="text-xl font-semibold mb-2">{restaurant.name}</h3>
                {/* Restaurant details */}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Restaurants;
