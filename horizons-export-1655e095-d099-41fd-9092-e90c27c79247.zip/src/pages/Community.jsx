
import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Heart, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Community = () => {
  const posts = [
    {
      id: 1,
      author: "Sarah B.",
      content: "Magnifique coucher de soleil à Tamanrasset !",
      likes: 124,
      comments: 18,
      timestamp: "2025-04-24T18:25:43.511Z"
    },
    // Add more posts
  ];

  return (
    <div className="container mx-auto p-6">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <Button className="w-full h-20 text-lg">
            Partagez votre expérience
          </Button>
        </div>

        {posts.map((post) => (
          <motion.div
            key={post.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow-lg mb-6 overflow-hidden"
          >
            <div className="p-4">
              <div className="flex items-center mb-4">
                <img  alt="User profile" className="w-10 h-10 rounded-full mr-3" src="https://images.unsplash.com/photo-1652841190565-b96e0acbae17" />
                <div>
                  <h3 className="font-semibold">{post.author}</h3>
                  <p className="text-sm text-gray-500">
                    {new Date(post.timestamp).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <p className="mb-4">{post.content}</p>

              <img  alt="Post image" className="w-full h-64 object-cover rounded-lg mb-4" src="https://images.unsplash.com/photo-1682685796063-d2604827f7b3" />

              <div className="flex items-center gap-6">
                <Button variant="ghost" size="sm">
                  <Heart className="h-4 w-4 mr-2" />
                  {post.likes}
                </Button>
                <Button variant="ghost" size="sm">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  {post.comments}
                </Button>
                <Button variant="ghost" size="sm">
                  <Share2 className="h-4 w-4 mr-2" />
                  Partager
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Community;
