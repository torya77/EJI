
import React from "react";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

const Home = () => {
  const { t } = useTranslation();

  return (
    <div className="relative min-h-[calc(100vh-4rem)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl sm:text-6xl font-bold text-[#151B54] mb-4">
              {t('welcome')}
            </h1>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="flex justify-center mb-8"
          >
            <div className="grid grid-cols-3 gap-0 w-full max-w-4xl h-[300px] overflow-hidden rounded-lg shadow-xl">
              <img alt="Montagnes de Kabylie" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1691003854453-62738cbb9afa" />
              <img  alt="Vue sur Alger et la Méditerranée" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1562619438-4ba4788886de" />
              <img alt="Désert du Sahara" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1631117246758-81e4c0798912" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <p className="text-xl sm:text-2xl text-[#151B54] mb-8">
              {t('discover')}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button size="lg" className="bg-[#151B54] hover:bg-[#151B54]/90 text-white">
              {t('startExploring')}
            </Button>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white/80 backdrop-blur-sm rounded-lg p-6 shadow-lg"
            >
              <img alt="Traditional Algerian architecture" className="w-full h-48 object-cover rounded-md mb-4" src="https://images.unsplash.com/photo-1570133435537-3946aea51b54" />
              <h3 className="text-xl font-semibold text-[#151B54] mb-2">Découvrez la Culture</h3>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-white/80 backdrop-blur-sm rounded-lg p-6 shadow-lg"
            >
              <img alt="Sahara desert landscape" className="w-full h-48 object-cover rounded-md mb-4" src="https://images.unsplash.com/photo-1631117246758-81e4c0798912" />
              <h3 className="text-xl font-semibold text-[#151B54] mb-2">Explorez le Sahara</h3>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="bg-white/80 backdrop-blur-sm rounded-lg p-6 shadow-lg"
            >
              <img alt="Mediterranean coastline" className="w-full h-48 object-cover rounded-md mb-4" src="https://images.unsplash.com/photo-1656350365435-278c8e953386" />
              <h3 className="text-xl font-semibold text-[#151B54] mb-2">Visitez le Littoral</h3>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
