
import React, { useState, useEffect } from "react";
import Map, { Marker, Popup, NavigationControl, FullscreenControl } from "react-map-gl";
import { motion, AnimatePresence } from "framer-motion";
import { Calendar, MapPin, Clock, Info, Search, Filter, Heart, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import "mapbox-gl/dist/mapbox-gl.css";

const MapView = () => {
  const [viewState, setViewState] = useState({
    latitude: 36.7538,
    longitude: 3.0588,
    zoom: 5,
    bearing: 0,
    pitch: 0
  });

  const [selectedEvent, setSelectedEvent] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [showCalendar, setShowCalendar] = useState(false);
  const [favorites, setFavorites] = useState([]);
  const [events] = useState([
    {
      id: 1,
      title: "Festival International de Timgad",
      description: "Festival de musique et de culture dans les ruines romaines",
      latitude: 35.4848,
      longitude: 6.4701,
      date: "2025-07-15",
      time: "20:00",
      category: "culture",
      region: "Est"
    },
    {
      id: 2,
      title: "Festival de Djemila",
      description: "Célébration de la musique traditionnelle algérienne",
      latitude: 36.3215,
      longitude: 5.7377,
      date: "2025-08-01",
      time: "21:00",
      category: "music",
      region: "Est"
    },
    {
      id: 3,
      title: "Salon de l'Artisanat d'Alger",
      description: "Exposition des artisans traditionnels",
      latitude: 36.7538,
      longitude: 3.0588,
      date: "2025-06-20",
      time: "10:00",
      category: "artisanat",
      region: "Centre"
    },
    {
      id: 4,
      title: "Festival des Oasis de Djanet",
      description: "Découverte de la culture touareg",
      latitude: 24.5500,
      longitude: 9.4833,
      date: "2025-09-15",
      time: "18:00",
      category: "culture",
      region: "Sud"
    },
    {
      id: 5,
      title: "Fête des Cerises de Tlemcen",
      description: "Célébration de la récolte des cerises",
      latitude: 34.8783,
      longitude: -1.3150,
      date: "2025-06-10",
      time: "09:00",
      category: "festival",
      region: "Ouest"
    }
  ]);

  const categories = ["all", "culture", "music", "artisanat", "festival"];
  const regions = ["Toutes", "Nord", "Sud", "Est", "Ouest", "Centre"];

  const filteredEvents = events.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.region.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || event.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleFavorite = (eventId) => {
    setFavorites(prev => {
      const isCurrentlyFavorite = prev.includes(eventId);
      if (isCurrentlyFavorite) {
        return prev.filter(id => id !== eventId);
      } else {
        return [...prev, eventId];
      }
    });
  };

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === "Escape") {
        setSelectedEvent(null);
      }
    };
    window.addEventListener("keydown", handleEscape);
    return () => {
      window.removeEventListener("keydown", handleEscape);
    };
  }, []);

  return (
    <div className="relative h-[calc(100vh-4rem)]">
      {/* Barre de recherche et filtres */}
      <div className="absolute top-4 left-4 right-4 z-10 flex gap-4 flex-wrap">
        <div className="flex-1 min-w-[200px] max-w-md bg-white rounded-lg shadow-lg p-2 flex items-center gap-2">
          <Search className="w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher un événement ou une région..."
            className="w-full bg-transparent border-none focus:outline-none text-[#151B54]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="bg-white rounded-lg shadow-lg p-2 flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-400" />
          <select
            className="bg-transparent border-none focus:outline-none text-[#151B54]"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </option>
            ))}
          </select>
        </div>

        <Button
          variant="outline"
          className="bg-white shadow-lg"
          onClick={() => setShowCalendar(!showCalendar)}
        >
          <CalendarDays className="w-5 h-5 mr-2" />
          Calendrier
        </Button>
      </div>

      <Map
        {...viewState}
        onMove={evt => setViewState(evt.viewState)}
        mapStyle="mapbox://styles/mapbox/streets-v12"
        mapboxAccessToken="pk.eyJ1IjoiZXhhbXBsZSIsImEiOiJjbGxxOHVqY2QwMGRpMnFwaW9zcGNhOXpwIn0.6CdwEKWzwGkXQYBNkRq2Uw"
      >
        <NavigationControl position="top-right" />
        <FullscreenControl position="top-right" />

        {filteredEvents.map((event) => (
          <Marker
            key={event.id}
            latitude={event.latitude}
            longitude={event.longitude}
            anchor="bottom"
            onClick={e => {
              e.originalEvent.stopPropagation();
              setSelectedEvent(event);
            }}
          >
            <motion.div
              whileHover={{ scale: 1.2 }}
              className="cursor-pointer"
            >
              <MapPin className="w-6 h-6 text-[#151B54]" />
            </motion.div>
          </Marker>
        ))}

        <AnimatePresence>
          {selectedEvent && (
            <Popup
              latitude={selectedEvent.latitude}
              longitude={selectedEvent.longitude}
              anchor="bottom"
              onClose={() => setSelectedEvent(null)}
              closeOnClick={false}
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="p-2 max-w-xs"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-semibold text-[#151B54]">
                    {selectedEvent.title}
                  </h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1"
                    onClick={() => toggleFavorite(selectedEvent.id)}
                  >
                    <Heart
                      className={`w-5 h-5 ${
                        favorites.includes(selectedEvent.id)
                          ? "fill-red-500 text-red-500"
                          : "text-gray-400"
                      }`}
                    />
                  </Button>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                  {selectedEvent.description}
                </p>
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-1">
                  <Calendar className="w-4 h-4" />
                  {selectedEvent.date}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                  <Clock className="w-4 h-4" />
                  {selectedEvent.time}
                </div>
                <Button 
                  size="sm" 
                  className="w-full bg-[#151B54] hover:bg-[#151B54]/90 text-white"
                  onClick={() => {
                    console.log("Réserver pour:", selectedEvent.title);
                  }}
                >
                  Réserver
                </Button>
              </motion.div>
            </Popup>
          )}
        </AnimatePresence>
      </Map>

      {/* Calendrier des événements */}
      <AnimatePresence>
        {showCalendar && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm p-4 rounded-lg shadow-lg max-w-md"
          >
            <h3 className="text-lg font-semibold text-[#151B54] mb-4">Calendrier des événements</h3>
            <div className="space-y-2">
              {events
                .sort((a, b) => new Date(a.date) - new Date(b.date))
                .map(event => (
                  <div
                    key={event.id}
                    className="flex items-center gap-2 p-2 hover:bg-gray-50 rounded-lg cursor-pointer"
                    onClick={() => {
                      setSelectedEvent(event);
                      setViewState(prev => ({
                        ...prev,
                        latitude: event.latitude,
                        longitude: event.longitude,
                        zoom: 12
                      }));
                    }}
                  >
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium text-[#151B54]">{event.title}</p>
                      <p className="text-xs text-gray-500">{event.date}</p>
                    </div>
                  </div>
                ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Liste des favoris */}
      {favorites.length > 0 && (
        <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm p-4 rounded-lg shadow-lg max-w-xs">
          <h3 className="text-lg font-semibold text-[#151B54] mb-2 flex items-center gap-2">
            <Heart className="w-5 h-5 fill-red-500 text-red-500" />
            Favoris
          </h3>
          <div className="space-y-2">
            {events
              .filter(event => favorites.includes(event.id))
              .map(event => (
                <div
                  key={event.id}
                  className="flex items-center justify-between gap-2 p-2 hover:bg-gray-50 rounded-lg cursor-pointer"
                  onClick={() => {
                    setSelectedEvent(event);
                    setViewState(prev => ({
                      ...prev,
                      latitude: event.latitude,
                      longitude: event.longitude,
                      zoom: 12
                    }));
                  }}
                >
                  <p className="text-sm text-[#151B54]">{event.title}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(event.id);
                    }}
                  >
                    <Heart className="w-4 h-4 fill-red-500 text-red-500" />
                  </Button>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default MapView;
