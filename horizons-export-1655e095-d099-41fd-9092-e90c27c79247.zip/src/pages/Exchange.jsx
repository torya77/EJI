
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Exchange = () => {
  const [amount, setAmount] = useState('');
  const [fromCurrency, setFromCurrency] = useState('EUR');
  const [toCurrency, setToCurrency] = useState('DZD');
  const [result, setResult] = useState(null);

  const currencies = {
    EUR: 'Euro',
    USD: 'Dollar US',
    DZD: 'Dinar Algérien',
    GBP: 'Livre Sterling'
  };

  const handleExchange = () => {
    // Implement exchange rate calculation
  };

  return (
    <div className="container mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6"
      >
        <h2 className="text-2xl font-bold mb-6">Convertisseur de devises</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Montant</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full p-2 border rounded-md"
              placeholder="Entrez le montant"
            />
          </div>

          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium mb-2">De</label>
              <select
                value={fromCurrency}
                onChange={(e) => setFromCurrency(e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                {Object.entries(currencies).map(([code, name]) => (
                  <option key={code} value={code}>
                    {name} ({code})
                  </option>
                ))}
              </select>
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setFromCurrency(toCurrency);
                setToCurrency(fromCurrency);
              }}
            >
              <RefreshCcw className="h-4 w-4" />
            </Button>

            <div className="flex-1">
              <label className="block text-sm font-medium mb-2">Vers</label>
              <select
                value={toCurrency}
                onChange={(e) => setToCurrency(e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                {Object.entries(currencies).map(([code, name]) => (
                  <option key={code} value={code}>
                    {name} ({code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <Button
            className="w-full"
            onClick={handleExchange}
          >
            Convertir
          </Button>

          {result && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-primary/5 rounded-md"
            >
              <p className="text-center text-lg font-semibold">
                {amount} {fromCurrency} = {result} {toCurrency}
              </p>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default Exchange;
