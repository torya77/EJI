
import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { useToast } from "@/components/ui/use-toast";
import ImageTranslator from '@/components/ImageTranslator';
import TextInput from '@/components/TextInput';
import TranslationOutput from '@/components/TranslationOutput';

const Translator = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [text, setText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('fr');
  const [detectedLanguage, setDetectedLanguage] = useState('');
  const [showTextInput, setShowTextInput] = useState(false);

  const languages = [
    { code: 'fr', name: 'Français' },
    { code: 'ar', name: 'العربية' },
    { code: 'en', name: 'English' },
    { code: 'de', name: 'Deutsch' }
  ];

  const detectLanguage = async (text) => {
    try {
      const response = await fetch('https://translation.googleapis.com/language/translate/v2/detect', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_GOOGLE_TRANSLATE_API_KEY}`,
        },
        body: JSON.stringify({
          q: text
        })
      });
      
      const data = await response.json();
      setDetectedLanguage(data.data.detections[0][0].language);
    } catch (error) {
      console.error('Erreur de détection de langue:', error);
    }
  };

  const handleTextExtracted = async (extractedText) => {
    setText(extractedText);
    await detectLanguage(extractedText);
  };

  const translateText = useCallback(async () => {
    if (!text) return;

    try {
      setIsProcessing(true);
      const response = await fetch('https://translation.googleapis.com/language/translate/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_GOOGLE_TRANSLATE_API_KEY}`,
        },
        body: JSON.stringify({
          q: text,
          target: selectedLanguage,
          source: detectedLanguage || 'auto'
        })
      });
      
      const data = await response.json();
      setTranslatedText(data.data.translations[0].translatedText);
      
      toast({
        title: "Traduction effectuée",
        description: "Le texte a été traduit avec succès.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erreur de traduction",
        description: "Impossible de traduire le texte.",
      });
    } finally {
      setIsProcessing(false);
    }
  }, [text, selectedLanguage, detectedLanguage, toast]);

  return (
    <div className="container mx-auto p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto space-y-6"
      >
        <div className="bg-white rounded-lg p-6 shadow-lg">
          <h2 className="text-2xl font-bold mb-4 text-[#151B54]">
            Traducteur de menus et panneaux
          </h2>
          
          <div className="space-y-4">
            <div className="flex gap-4">
              <ImageTranslator
                onTextExtracted={handleTextExtracted}
                isProcessing={isProcessing}
                toast={toast}
              />
              
              <TextInput
                text={text}
                setText={setText}
                showTextInput={showTextInput}
                setShowTextInput={setShowTextInput}
                isProcessing={isProcessing}
              />
            </div>

            <TranslationOutput
              text={text}
              translatedText={translatedText}
              selectedLanguage={selectedLanguage}
              setSelectedLanguage={setSelectedLanguage}
              languages={languages}
              detectedLanguage={detectedLanguage}
              isProcessing={isProcessing}
              onTranslate={translateText}
            />
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Translator;
